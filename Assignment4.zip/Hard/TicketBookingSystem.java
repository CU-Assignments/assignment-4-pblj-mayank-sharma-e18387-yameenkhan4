
import java.util.concurrent.*;

class TicketBooking implements Runnable {
    private final String passengerName;

    public TicketBooking(String passengerName) {
        this.passengerName = passengerName;
    }

    @Override
    public void run() {
        System.out.println("Booking ticket for: " + passengerName);
        try {
            Thread.sleep(2000); // Simulate booking process
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        System.out.println("Ticket booked successfully for: " + passengerName);
    }
}

public class TicketBookingSystem {
    public static void main(String[] args) {
        ExecutorService executor = Executors.newFixedThreadPool(3);

        executor.execute(new TicketBooking("Alice"));
        executor.execute(new TicketBooking("Bob"));
        executor.execute(new TicketBooking("Charlie"));

        executor.shutdown();
    }
}
