
import java.util.*;

public class CardCollection {
    public static void main(String[] args) {
        Set<String> cards = new HashSet<>();
        cards.add("Ace of Spades");
        cards.add("King of Hearts");
        cards.add("Queen of Diamonds");
        cards.add("Jack of Clubs");

        System.out.println("Card Collection:");
        cards.forEach(System.out::println);
    }
}
