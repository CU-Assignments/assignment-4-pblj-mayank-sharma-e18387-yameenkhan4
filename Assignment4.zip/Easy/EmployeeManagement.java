
import java.util.*;

class Employee {
    private int id;
    private String name;
    private String department;

    public Employee(int id, String name, String department) {
        this.id = id;
        this.name = name;
        this.department = department;
    }

    @Override
    public String toString() {
        return "ID: " + id + ", Name: " + name + ", Department: " + department;
    }
}

public class EmployeeManagement {
    public static void main(String[] args) {
        List<Employee> employees = new ArrayList<>();
        employees.add(new Employee(1, "Alice", "HR"));
        employees.add(new Employee(2, "Bob", "IT"));
        employees.add(new Employee(3, "Charlie", "Finance"));

        System.out.println("Employee List:");
        employees.forEach(System.out::println);
    }
}
