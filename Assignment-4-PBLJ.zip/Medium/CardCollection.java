
import java.util.*;

public class CardCollection {
    private static final Map<String, List<String>> cards = new HashMap<>();

    public static void main(String[] args) {
        addCard("Hearts", "Ace");
        addCard("Hearts", "King");
        addCard("Spades", "Queen");
        addCard("Diamonds", "Jack");

        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter card symbol to search: ");
        String symbol = scanner.nextLine();

        displayCards(symbol);
        scanner.close();
    }

    public static void addCard(String symbol, String value) {
        cards.putIfAbsent(symbol, new ArrayList<>());
        cards.get(symbol).add(value);
    }

    public static void displayCards(String symbol) {
        if (cards.containsKey(symbol)) {
            System.out.println("Cards under symbol " + symbol + ": " + cards.get(symbol));
        } else {
            System.out.println("No cards found for symbol: " + symbol);
        }
    }
}
