
class TicketBookingSystem {
    private static int availableSeats = 10;

    public static synchronized void bookTicket(String name, int seats) {
        if (seats <= availableSeats) {
            System.out.println(name + " successfully booked " + seats + " seat(s).");
            availableSeats -= seats;
        } else {
            System.out.println("Not enough seats for " + name + "'s request.");
        }
    }

    public static void main(String[] args) {
        Thread vipThread = new Thread(() -> bookTicket("VIP", 4));
        Thread userThread1 = new Thread(() -> bookTicket("User1", 3));
        Thread userThread2 = new Thread(() -> bookTicket("User2", 5));

        vipThread.setPriority(Thread.MAX_PRIORITY);
        userThread1.setPriority(Thread.NORM_PRIORITY);
        userThread2.setPriority(Thread.NORM_PRIORITY);

        vipThread.start();
        userThread1.start();
        userThread2.start();
    }
}
